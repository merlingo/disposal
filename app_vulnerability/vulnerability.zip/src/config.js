export default {
  auth: {
    email: 'admin@flatlogic.com',
    password: 'password'
  }
};
