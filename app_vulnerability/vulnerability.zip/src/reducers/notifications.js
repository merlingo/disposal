import {
    NOTICE_GET, NOTICE_UPDATED, NOTICE_DELETE,
} from '../actions/notification';

export default function notification(state = {

    isFetching: false,
}, action) {
   switch (action.type) {
       case NOTICE_GET:
           return Object.assign({}, state, {

           });
       case NOTICE_UPDATED:
           return Object.assign({}, state, {

           });
       case NOTICE_DELETE:
           return Object.assign({}, state, {
               
           });
       default:
           return state;
   }
}
