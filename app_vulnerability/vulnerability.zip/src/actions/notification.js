export const NOTICE_GET = 'NOTICE_GET';
export const NOTICE_UPDATED = 'NOTICE_UPDATED';
export const NOTICE_DELETE = 'NOTICE_DELETE';


export function receiveNotice() {
    return {
        type: NOTICE_GET,
    };
}

function updateNotice(payload) {
    return {
        type: NOTICE_UPDATED,
        payload,
    };
}

function deleteNotice() {
    return {
        type: NOTICE_DELETE,
    };
}
