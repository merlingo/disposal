import React, { useEffect, useState } from "react";
import {
  Row,
  Col,
} from "reactstrap";
import { Tabs, Tab, TabPanel, TabList } from 'react-web-tabs';
import Select from 'react-select';
import 'react-web-tabs/dist/react-web-tabs.css';
import as from "./Alarm.module.scss";

import BootstrapTable from 'react-bootstrap-table-next';
import ToolkitProvider, { Search } from 'react-bootstrap-table2-toolkit';
import paginationFactory from 'react-bootstrap-table2-paginator';

const Alarm = () => {

    const [todos, setTodos] = useState(
        [
            { text: "Learn about React" },
            { text: "Meet friend for lunch" },
            { text: "Build really cool todo app" }
        ]
    );

    const [selVendor, setSelVendor] = useState('');
    const [selProduct, setSelProduct] = useState('');
    const [selVul, setSelVul] = useState('');

    const [curVendor, setCurVendors] = useState([
        'Microsoft',
        'Apple',
        'iPhone'
    ]);

    const [curProduct, setCurProduct] = useState([
        'Microsoft',
        'Apple',
        'iPhone'
    ]);

    const [curVulnerability, setCurVulnerability] = useState([
        'Microsoft',
        'Apple',
        'iPhone'
    ]);
    
    const [vendors, setVendors] = useState(
        [
            { label: "MicroSoft", value: 355 },
            { label: "Apple", value: 54 },
            { label: "Unix", value: 43 },
        ]
    );

    const [product, setProduct] = useState(
        [
            { label: "Office", value: 355 },
            { label: "Edge", value: 54 },
            { label: "Azure", value: 43 },
        ]
    );

    const [vulnerability, setVulnerability] = useState(
        [
            { label: "RCE", value: 355 },
            { label: "XSS", value: 54 },
            { label: "SQL Injection", value: 43 },
        ]
    );

  const columns = [
    {
      dataField: 'id',
      text: 'Product ID'
    }, 
    {
      dataField: 'name',
      text: 'Product Name'
    }, 
    {
      dataField: 'price',
      text: 'Product Price'
    }
  ];

  const products = [
    {
      id: 1,
      name: 'Item name 0',
      price: '2100'
    },
    {
      id: 2,
      name: 'Test name',
      price: '2500'
    },
    {
      id: 3,
      name: 'Hello World',
      price: '5100'
    },
    {
      id: 4,
      name: 'Item name 0',
      price: '2100'
    },
    {
      id: 5,
      name: 'Test name',
      price: '2500'
    },
    {
      id: 6,
      name: 'Hello World',
      price: '5100'
    },
    {
      id: 7,
      name: 'Item name 0',
      price: '2100'
    },
    {
      id: 8,
      name: 'Test name',
      price: '2500'
    },
    {
      id: 9,
      name: 'Hello World',
      price: '5100'
    },
    {
      id: 10,
      name: 'Item name 0',
      price: '2100'
    },
    {
      id: 11,
      name: 'Test name',
      price: '2500'
    },
    {
      id: 12,
      name: 'Hello World',
      price: '5100'
    },
    {
      id: 13,
      name: 'Item name 0',
      price: '2100'
    },
    {
      id: 14,
      name: 'Test name',
      price: '2500'
    },
    {
      id: 15,
      name: 'Hello World',
      price: '5100'
    },
  ];

  const rowEvents = {
    onClick: (e, row, rowIndex) => {
        setTodos([...todos, { text: row.name}]);
    }
  };

  const saveAlarms = () => {
    setCurVendors([...curVendor, selVendor])
    setCurProduct([...curProduct, selProduct])
    setCurVulnerability([...curVulnerability, selVul])
    setSelVendor('')
    setSelProduct('')
    setSelVul('')
  }

  const handleChangeVendor = (selectedOptions) => {
    setSelVendor(selectedOptions.label);
  }

  const handleChangeProduct = (selectedOptions) => {
    setSelProduct(selectedOptions.label);
  }

  const handleChangeVulnerability = (selectedOptions) => {
    setSelVul(selectedOptions.label);
  }

  useEffect(() => {
  });
 
  return (
    <div>
        <Row>
            <Tabs defaultTab="vertical-tab-one" vertical className={as.tabs}>
                <Col lg={3} md={3} sm={3}>
                    <TabList>
                        <Tab tabFor="vertical-tab-one" className={as.tab_name}>Alarms</Tab>
                        <Tab tabFor="vertical-tab-two" className={as.tab_name}>Options</Tab>
                    </TabList>
                </Col>
                <Col lg={9} md={9} sm={9}>
                    <TabPanel tabId="vertical-tab-one">
                        <ToolkitProvider
                            keyField="id"
                            data={ products }
                            columns={ columns }
                            search
                        >
                        {
                            props => (
                                <div>
                                    <BootstrapTable
                                        { ...props.baseProps }
                                        pagination={ paginationFactory() }
                                        rowEvents={ rowEvents }
                                        bootstrap4 
                                        keyField='id'
                                        striped
                                        hover
                                    />
                                </div>
                            )
                        }
                        </ToolkitProvider>
                    </TabPanel>
                    <TabPanel tabId="vertical-tab-two">
                        <Row>
                            <Col lg={4} md={4} sm={4}>
                                <label><h3>Vendor</h3></label>
                                <ul>
                                {
                                    curVendor.map((index, key) =>
                                        <li key={key}>{index}</li>
                                    )
                                }
                                </ul>
                            </Col>
                            <Col lg={4} md={4} sm={4}>
                                <label><h3>Product</h3></label>
                                <ul>
                                {
                                    curProduct.map((index, key) =>
                                        <li key={key}>{index}</li>
                                    )
                                }
                                </ul>
                            </Col>
                            <Col lg={4} md={4} sm={4}>
                                <label><h3>Vulnerability</h3></label>
                                <ul>
                                {
                                    curVulnerability.map((index, key) =>
                                        <li key={key}>{index}</li>
                                    )
                                }
                                </ul>
                            </Col>
                        </Row>
                        <hr/>
                        <Row>
                            <Col lg={4} md={4} sm={4}>
                                <label>Vendors:</label>
                                <Select options={vendors} className={as.select} onChange={handleChangeVendor} />
                            </Col>
                            <Col lg={4} md={4} sm={4}>
                                <label>Products:</label>
                                <Select options={product} className={as.select} onChange={handleChangeProduct} />
                            </Col>
                            <Col lg={4} md={4} sm={4}>
                                <label>Vulnerability:</label>
                                <Select options={vulnerability} className={as.select}  onChange={handleChangeVulnerability} />
                            </Col>
                        </Row>
                        <button onClick={saveAlarms} className={`btn btn-primary ${as.save_btn}`}>Save</button>
                    </TabPanel>

                </Col>
            </Tabs>
        </Row>
    </div>
  );
};

export default Alarm;
