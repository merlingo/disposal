import React, { useEffect } from 'react';
import s from './todo.module.scss'; 

const Todo = (todo) => {

    useEffect(() => {
       console.log('tst = ', todo);
    });

    return (
        <div className={s.todo} onClick={() => todo.selectProduct(todo.text)}>
          {todo.text}
        </div>
    );
}

export default Todo;