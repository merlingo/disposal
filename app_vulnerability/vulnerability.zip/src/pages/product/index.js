import React, { useEffect, useState } from "react";
import classnames from 'classnames';
import {
  Row,
  Col,
  Modal,
  ModalHeader, 
  ModalBody, 
  TabContent, 
  TabPane,
  Nav, 
  NavItem, 
  NavLink
} from "reactstrap";
import Widget from "../../components/Widget";
import Todo from "../components/todo";
import ps from "./Product.module.scss";

import BootstrapTable from 'react-bootstrap-table-next';
import ToolkitProvider, { Search } from 'react-bootstrap-table2-toolkit';
import paginationFactory from 'react-bootstrap-table2-paginator';

const Product = () => {

  const { SearchBar, ClearSearchButton } = Search;

  const [modalShow, setModalShow] = useState(false);

  const [activeTab, setActiveTab] = useState('1');

  // const [products, setProducts] = useState([]);

  const [tabData, setTabData] = useState(["Hello World"]);

  const handleModalClose = () => setModalShow(false);

  const changeTab = tab => {
    if(activeTab !== tab) setActiveTab(tab);
  }

  const [todos, setTodos] = useState(
    [
      { text: "Learn about React" },
      { text: "Meet friend for lunch" },
      { text: "Build really cool todo app" }
    ]
  );

  const columns = [
    {
      dataField: 'id',
      text: 'Product ID'
    }, 
    {
      dataField: 'name',
      text: 'Product Name'
    }, 
    {
      dataField: 'price',
      text: 'Product Price'
    }
  ];

  const products = [
    {
      id: 1,
      name: 'Item name 0',
      price: '2100'
    },
    {
      id: 2,
      name: 'Test name',
      price: '2500'
    },
    {
      id: 3,
      name: 'Hello World',
      price: '5100'
    },
    {
      id: 4,
      name: 'Item name 0',
      price: '2100'
    },
    {
      id: 5,
      name: 'Test name',
      price: '2500'
    },
    {
      id: 6,
      name: 'Hello World',
      price: '5100'
    },
    {
      id: 7,
      name: 'Item name 0',
      price: '2100'
    },
    {
      id: 8,
      name: 'Test name',
      price: '2500'
    },
    {
      id: 9,
      name: 'Hello World',
      price: '5100'
    },
    {
      id: 10,
      name: 'Item name 0',
      price: '2100'
    },
    {
      id: 11,
      name: 'Test name',
      price: '2500'
    },
    {
      id: 12,
      name: 'Hello World',
      price: '5100'
    },
    {
      id: 13,
      name: 'Item name 0',
      price: '2100'
    },
    {
      id: 14,
      name: 'Test name',
      price: '2500'
    },
    {
      id: 15,
      name: 'Hello World',
      price: '5100'
    },
  ];

  const addProduct = () => {
        
    // getProductListForModal()

    //setProducts();

    setModalShow(true);
  }

  const getProductData = (pro) => {
    setTabData(pro);
  }

  const rowEvents = {
    onClick: (e, row, rowIndex) => {
      setTodos([...todos, { text: row.name}]);
    }
  };

  useEffect(() => {
  });
 
  return (
    <div>
      <Row>
        <Col lg={3} md={3} sm={3}>
          <h1> Products </h1>
          <Widget>
            <div className="todo-list">
              {todos.map((todo, index) => (
                <Todo
                  key={index}
                  index={index}
                  text={todo.text}
                  selectProduct={getProductData}
                />
              ))}
            </div>
            <button className={ps.add_product_btn} onClick={addProduct}>Add</button>
          </Widget>
        </Col>
        <Col lg={9} md={9} sm={9}>
          <Nav tabs>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === '1' })}
                onClick={() => { changeTab('1'); }}
              >
                Details
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === '2' })}
                onClick={() => { changeTab('2'); }}
              >
                Vulnerability
              </NavLink>
            </NavItem>
          </Nav>
          <TabContent activeTab={activeTab}>
            <TabPane tabId="1">{tabData}</TabPane>
            <TabPane tabId="2">Tab 2 Content</TabPane>
          </TabContent>
        </Col>
      </Row>
      <Modal isOpen={modalShow} toggle={handleModalClose} >
        <ModalHeader toggle={handleModalClose}>Products List</ModalHeader>
        <ModalBody>
          <ToolkitProvider
            keyField="id"
            data={ products }
            columns={ columns }
            search
          >
            {
              props => (
                <div>
                  <SearchBar { ...props.searchProps } />
                  <hr />
                  <BootstrapTable
                    { ...props.baseProps }
                    pagination={ paginationFactory() }
                    rowEvents={ rowEvents }
                    bootstrap4 
                    keyField='id'
                    striped
                    hover
                  />
                </div>
              )
            }
          </ToolkitProvider>
        </ModalBody>
      </Modal>
    </div>
  );
};

export default Product;
